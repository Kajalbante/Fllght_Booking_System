import React from 'react';
import QrGenerator from './Component/QrGenerator';

function App() {
  return (
    <div className="App">
      <QrGenerator />
    </div>
  );
}

export default App;
